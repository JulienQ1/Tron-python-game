# Tron-python-game

Students: 
- Julien Quenneville
- Wu Yedong
- Keith Udani
- Antoine Martinet

Tron game accesible by 4 player with local network in python 

https://www.pygame.org/wiki/GettingStarted

# TRON

The code implement the TRON game, which is based on the TRON Film released in 1984. <br>
To start the game, just run  ...  with python

## About the Game 

It's a snake-like game where you have to control a bike with a tail. You die, if you drive in the tail of an enemy (or in you're own tail) or in the border of the field. The goal is to be the last driver surviving. <br>






